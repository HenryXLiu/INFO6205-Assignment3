package edu.neu.coe.info6205.graphs.undirected;

public interface Position {

    double getX();

    double getY();
}
